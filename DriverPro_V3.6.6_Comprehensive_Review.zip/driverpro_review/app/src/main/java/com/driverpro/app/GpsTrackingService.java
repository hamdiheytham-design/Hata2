package com.driverpro.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;

import androidx.core.app.NotificationCompat;

import org.json.JSONArray;
import org.json.JSONObject;

public class GpsTrackingService extends Service {
    public static final String ACTION_START = "com.driverpro.app.GPS_START";
    public static final String ACTION_STOP = "com.driverpro.app.GPS_STOP";
    public static final String ACTION_LOCATION = "com.driverpro.app.GPS_LOCATION";
    public static final String ACTION_STATUS = "com.driverpro.app.GPS_STATUS";
    public static final String EXTRA_STATUS = "status";
    public static final String EXTRA_MESSAGE = "message";
    public static final String EXTRA_LAT = "lat";
    public static final String EXTRA_LON = "lon";
    public static final String EXTRA_ACCURACY = "accuracy";
    public static final String EXTRA_TIME = "time";
    private static final int NOTIFICATION_ID = 2601;
    private static final String CHANNEL_ID = "driverpro_gps_tracking";
    private static final String ARRIVAL_CHANNEL_ID = "driverpro_arrival_alerts";
    private static final int ARRIVAL_NOTIFICATION_ID = 2602;
    private static final String PREFS = "driverpro_gps_native";
    private static final String KEY_POINTS = "points";

    private LocationManager locationManager;
    private LocationListener listener;
    private Location lastAccepted;
    public static volatile boolean trackingActive = false;

    @Override public void onCreate() {
        super.onCreate();
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        createNotificationChannel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? null : intent.getAction();
        if (ACTION_STOP.equals(action)) {
            stopTracking("stopped", "تم إيقاف تتبع GPS.");
            return START_NOT_STICKY;
        }
        if (ACTION_START.equals(action)) {
            // Clear route history only when the user explicitly starts a new tracking session.
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_POINTS, "[]").putBoolean("tracking", true).apply();
            lastAccepted = null;
        } else if (intent == null && !getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean("tracking", false)) {
            stopSelf();
            return START_NOT_STICKY;
        }
        trackingActive = true;
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean("tracking", true).apply();
        startForeground(NOTIFICATION_ID, buildNotification());
        startLocationUpdates();
        return START_STICKY;
    }

    private void startLocationUpdates() {
        if (listener != null) return;
        boolean fine = Build.VERSION.SDK_INT < 23 || checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
        boolean coarse = Build.VERSION.SDK_INT < 23 || checkSelfPermission(android.Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
        if (!fine && !coarse) { stopTracking("denied", "إذن الموقع غير متاح."); return; }
        try {
            String provider = fine ? LocationManager.GPS_PROVIDER : LocationManager.NETWORK_PROVIDER;
            if (!locationManager.isProviderEnabled(provider)) { stopTracking("error", "فعّل خدمة الموقع GPS من إعدادات الهاتف."); return; }
            listener = new LocationListener() {
                @Override public void onLocationChanged(Location location) { acceptLocation(location); }
                @Override public void onStatusChanged(String provider, int status, Bundle extras) { }
                @Override public void onProviderEnabled(String provider) { broadcastStatus("started", "GPS يعمل في الخلفية."); }
                @Override public void onProviderDisabled(String provider) { broadcastStatus("error", "تم إيقاف خدمة الموقع في الهاتف."); }
            };
            locationManager.requestLocationUpdates(provider, 2000L, 3.0f, listener);
            broadcastStatus("started", "التتبع يعمل حتى عند إغلاق الشاشة. اضغط إيقاف من التطبيق أو الإشعار.");
            Location last = locationManager.getLastKnownLocation(provider);
            if (last != null) acceptLocation(last);
        } catch (SecurityException e) {
            stopTracking("denied", "لا توجد صلاحية للوصول إلى الموقع.");
        } catch (Exception e) {
            stopTracking("error", "تعذر تشغيل GPS في الخلفية.");
        }
    }

    private void acceptLocation(Location location) {
        if (location == null || (location.hasAccuracy() && location.getAccuracy() > 50f)) return;
        // Evaluate the arrival geofence for every sufficiently accurate fix, even if the vehicle is stationary.
        checkArrivalTarget(location);
        if (lastAccepted != null) {
            float[] result = new float[1];
            Location.distanceBetween(lastAccepted.getLatitude(), lastAccepted.getLongitude(), location.getLatitude(), location.getLongitude(), result);
            double km = result[0] / 1000.0;
            double seconds = Math.max(1.0, (location.getTime() - lastAccepted.getTime()) / 1000.0);
            double speed = km / seconds * 3600.0;
            if (km < 0.005 || speed > 160.0) return;
        }
        lastAccepted = new Location(location);
        JSONObject point = new JSONObject();
        try {
            point.put("lat", location.getLatitude());
            point.put("lon", location.getLongitude());
            point.put("accuracy", location.hasAccuracy() ? location.getAccuracy() : 999f);
            point.put("time", location.getTime());
            SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
            JSONArray points = new JSONArray(prefs.getString(KEY_POINTS, "[]"));
            points.put(point);
            if (points.length() > 10000) {
                JSONArray trimmed = new JSONArray();
                for (int i = points.length() / 2; i < points.length(); i += 2) trimmed.put(points.getJSONObject(i));
                points = trimmed;
            }
            prefs.edit().putString(KEY_POINTS, points.toString()).apply();
        } catch (Exception ignored) { }
        Intent update = new Intent(ACTION_LOCATION);
        update.setPackage(getPackageName());
        update.putExtra(EXTRA_LAT, location.getLatitude());
        update.putExtra(EXTRA_LON, location.getLongitude());
        update.putExtra(EXTRA_ACCURACY, location.hasAccuracy() ? location.getAccuracy() : 999f);
        update.putExtra(EXTRA_TIME, location.getTime());
        sendBroadcast(update);
    }

    private void checkArrivalTarget(Location current) {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (!prefs.getBoolean("arrivalActive", false) || prefs.getBoolean("arrivalNotified", false)) return;
        double targetLat = prefs.getFloat("arrivalLat", 0f);
        double targetLon = prefs.getFloat("arrivalLon", 0f);
        float radius = Math.max(50f, prefs.getFloat("arrivalRadius", 250f));
        float[] distance = new float[1];
        Location.distanceBetween(current.getLatitude(), current.getLongitude(), targetLat, targetLon, distance);
        if (distance[0] <= radius) {
            String label = prefs.getString("arrivalLabel", "الوجهة المحددة");
            prefs.edit().putBoolean("arrivalActive", false).putBoolean("arrivalNotified", true).apply();
            showArrivalNotification(label);
            broadcastStatus("arrived", "وصلت إلى الوجهة: " + label);
        }
    }

    private void showArrivalNotification(String label) {
        NotificationManager manager = getSystemService(NotificationManager.class);
        if (manager == null) return;
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pending = PendingIntent.getActivity(this, 3, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification notification = new NotificationCompat.Builder(this, ARRIVAL_CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_dialog_map)
                .setContentTitle("Driver Pro — وصلت إلى الوجهة")
                .setContentText(label)
                .setStyle(new NotificationCompat.BigTextStyle().bigText("أنت الآن ضمن نطاق الوصول المحدد: " + label))
                .setContentIntent(pending)
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setDefaults(NotificationCompat.DEFAULT_ALL)
                .build();
        manager.notify(ARRIVAL_NOTIFICATION_ID, notification);
    }

    private void stopTracking(String status, String message) {
        if (locationManager != null && listener != null) {
            try { locationManager.removeUpdates(listener); } catch (SecurityException ignored) { }
            listener = null;
        }
        trackingActive = false;
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean("tracking", false).apply();
        broadcastStatus(status, message);
        stopForeground(true);
        stopSelf();
    }

    private void broadcastStatus(String status, String message) {
        Intent update = new Intent(ACTION_STATUS);
        update.setPackage(getPackageName());
        update.putExtra(EXTRA_STATUS, status);
        update.putExtra(EXTRA_MESSAGE, message);
        sendBroadcast(update);
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "تتبع GPS - Driver Pro", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("إشعار دائم أثناء تسجيل مسار الرحلة");
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) {
                manager.createNotificationChannel(channel);
                NotificationChannel arrival = new NotificationChannel(ARRIVAL_CHANNEL_ID, "تنبيه الوصول - Driver Pro", NotificationManager.IMPORTANCE_HIGH);
                arrival.setDescription("تنبيه عند الاقتراب من الوجهة المحفوظة");
                arrival.enableVibration(true);
                manager.createNotificationChannel(arrival);
            }
        }
    }

    private Notification buildNotification() {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent openPending = PendingIntent.getActivity(this, 1, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent stop = new Intent(this, GpsTrackingService.class);
        stop.setAction(ACTION_STOP);
        PendingIntent stopPending = PendingIntent.getService(this, 2, stop, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_menu_mylocation)
                .setContentTitle("Driver Pro — تتبع GPS نشط")
                .setContentText("يتم تسجيل مسار الرحلة في الخلفية")
                .setContentIntent(openPending)
                .setOngoing(true)
                .addAction(android.R.drawable.ic_media_pause, "إيقاف التتبع", stopPending)
                .build();
    }

    @Override public void onDestroy() {
        trackingActive = false;
        if (locationManager != null && listener != null) {
            try { locationManager.removeUpdates(listener); } catch (SecurityException ignored) { }
        }
        listener = null;
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
